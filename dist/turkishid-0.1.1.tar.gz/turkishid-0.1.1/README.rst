turkishid
---------

Republic of Turkey Identity Number Validator.

Usage
~~~~~

First, you need to install package by running ``pip install turkishid``.
Then import your code.

.. code:: py

   import turkishid
   if turkishid.validate_id(11111111111) == True:
       print("Yay!")
